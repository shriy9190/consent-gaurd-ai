// popup.js v2

const app = document.getElementById("app");

function getRootDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function getRingColor(score) {
  score = Number(score);
  if (score >= 9) return "#dc2626";
  if (score >= 7) return "#ef4444";
  if (score >= 4) return "#f59e0b";
  return "#22c55e";
}

function renderAnalyzing(domain) {
  app.innerHTML = `
    <div class="state">
      <div class="spinner"></div>
      Finding &amp; analyzing <strong style="color:#6366f1">${domain}</strong>'s privacy policy…<br>
      This takes 20–30 seconds.
    </div>`;
}

function renderNotFound(domain) {
  app.innerHTML = `
    <div class="state">
      <div class="icon">🔍</div>
      Couldn't find a privacy policy for<br>
      <strong style="color:#6366f1">${domain}</strong><br><br>
      <span style="font-size:11px">Try visiting their privacy page directly.</span>
    </div>`;
}

function renderError() {
  app.innerHTML = `
    <div class="state">
      <div class="icon">⚠️</div>
      Analysis failed. Check that your backend is running.
    </div>`;
}

function renderIdle() {
  app.innerHTML = `
    <div class="state">
      <div class="icon">🛡️</div>
      Visit any website and ConsentGuard will automatically find and analyze their privacy policy.
    </div>`;
}

function toggleSection(id) {
  const body = document.getElementById(id);
  const icon = document.getElementById(id + "-icon");
  const open = body.classList.toggle("open");
  icon.textContent = open ? "▲" : "▼";
}

function makeSection(id, title, emoji, content, startOpen) {
  return `
    <div class="section">
      <div class="section-header" onclick="toggleSection('${id}')">
        <span class="section-title">${emoji} ${title}</span>
        <span class="section-toggle" id="${id}-icon">${startOpen ? "▲" : "▼"}</span>
      </div>
      <div class="section-body${startOpen ? " open" : ""}" id="${id}">
        ${content}
      </div>
    </div>`;
}

function renderResult(data, policyUrl, domain) {
  const color = getRingColor(data.score);
  const flags = data.flags || [];
  const cats  = data.categories || {};
  const pos   = data.positive_points || [];

  document.getElementById("site-domain").textContent = domain;

  const flagsHtml = flags.length
    ? flags.map(f => `
        <div class="flag-item">
          <span class="flag-dot"></span>
          <span>${f}</span>
        </div>`).join("")
    : `<span class="empty">No red flags found.</span>`;

  const catLabels = {
    data_collection: "What they collect",
    data_sharing   : "Who they share with",
    user_rights    : "Your rights",
    security       : "How they protect you"
  };
  let catsHtml = "";
  for (const [key, label] of Object.entries(catLabels)) {
    const items = cats[key] || [];
    catsHtml += `<div class="cat-label">${label}</div>`;
    catsHtml += items.length
      ? items.map(i => `<div class="cat-item">${i}</div>`).join("")
      : `<div class="cat-item empty">Nothing reported</div>`;
  }

  const posHtml = pos.length
    ? pos.map(p => `
        <div class="positive-item">
          <span class="positive-dot"></span>
          <span>${p}</span>
        </div>`).join("")
    : `<span class="empty">No positives found.</span>`;

  app.innerHTML = `
    <div class="score-section" style="--ring-color: ${color}">
      <div class="score-ring">
        <span class="score-num">${data.score}</span>
        <span class="score-denom">/10</span>
      </div>
      <div class="score-info">
        <div class="score-level">${data.level} RISK</div>
        <div class="score-summary">${data.summary || ""}</div>
      </div>
    </div>

    <div class="policy-link">
      📄 Policy: <a href="${policyUrl}" target="_blank">${policyUrl}</a>
    </div>

    ${data.cached ? `<span class="cached-badge">⚡ Cached result</span>` : ""}

    ${makeSection("flags",      `Red Flags (${flags.length})`, "🚩", flagsHtml, true)}
    ${makeSection("categories", "What They Do With Your Data",  "📋", catsHtml, false)}
    ${makeSection("positives",  "Positives",                    "✅", posHtml,  false)}
  `;
}

// ── Main ──
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url    = tabs[0]?.url;
  const domain = getRootDomain(url);

  if (!domain) { renderIdle(); return; }

  document.getElementById("site-domain").textContent = domain;

  const cacheKey = `domain:${domain}`;
  chrome.storage.local.get([cacheKey], (items) => {
    const entry = items[cacheKey];

    if (!entry)                        { renderIdle();              return; }
    if (entry.status === "analyzing")  { renderAnalyzing(domain);   return; }
    if (entry.status === "not_found")  { renderNotFound(domain);    return; }
    if (entry.status === "error")      { renderError();             return; }
    if (entry.status === "done")       {
      renderResult(entry.result, entry.policyUrl, domain);
      return;
    }

    renderIdle();
  });
});
